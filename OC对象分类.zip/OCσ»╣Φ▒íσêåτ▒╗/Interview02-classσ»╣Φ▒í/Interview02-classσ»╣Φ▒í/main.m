//
//  main.m
//  Interview02-class对象
//
//  Created by MJ Lee on 2018/4/8.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

@interface MJPerson : NSObject
{
    int _age;
    int _height;
    int _no;
}
@end

//@implementation MJPerson
//- (void)test;
//@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSObject *object1 = [[NSObject alloc] init];
        NSObject *object2 = [[NSObject alloc] init];

        //获取类对象的三种方式 ,并且类对象是唯一的
        Class objectClass1 = [object1 class];
        Class objectClass2 = [object2 class];
        Class objectClass3 = object_getClass(object1);
        Class objectClass4 = object_getClass(object2);
        Class objectClass5 = [NSObject class];

        //实例对象地址不一样
        NSLog(@"%p %p",
              object1,
              object2);
        //2019-11-22 13:58:55.203446+0800 Interview02-class对象[35317:3026477] 0x100534680 0x100534490

        //类对象地址一样的,是唯一的
        NSLog(@"%p %p %p %p %p",
              objectClass1,
              objectClass2,
              objectClass3,
              objectClass4,
              objectClass5);
        //2019-11-22 13:58:55.204264+0800 Interview02-class对象[35317:3026477] 0x7fff97e99140 0x7fff97e99140 0x7fff97e99140 0x7fff97e99140 0x7fff97e99140
    }
    return 0;
}



